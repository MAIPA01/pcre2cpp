#pragma once

#include <fmt/format.h>
#include <fmt/xchar.h>
#include <memory>
#include <mstd/mstd.hpp>
#include <pcre2.h>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

#pragma region config.hpp
#ifndef _PCRE2CPP_CONFIG_HPP_
	#define _PCRE2CPP_CONFIG_HPP_

/**
 *	@defgroup pcre2cpp PCRE2 C++
 *	@brief Main group
 */

/**
 * @defgroup utils Utilities
 * @brief group with utilities (not for end user to use)
 * @ingroup pcre2cpp
 */

/**
 * @namespace pcre2cpp
 * @brief Main namespace of pcre2cpp library
 */

/**
 * @namespace pcre2cpp::uitls
 * @brief Utility namespace of pcre2cpp library
 */

	#pragma region VERSION
	/**
	 * @brief pcre2cpp version major number
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION_MAJOR 1
	/**
	 * @brief pcre2cpp version minor number
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION_MINOR 2
	/**
	 * @brief pcre2cpp version patch number
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION_PATCH 4

	/**
	 * @brief stringify helper
	 * @ingroup utils
	 */
	#define _PCRE2CPP_STRINGIFY_HELPER(x) #x

	/**
	 * @brief converts version numbers to string
	 * @ingroup utils
	 */
	#define _PCRE2CPP_VERSION_TO_STRING(major, minor, patch)                                                          \
		_PCRE2CPP_STRINGIFY_HELPER(major) "." _PCRE2CPP_STRINGIFY_HELPER(minor) "." _PCRE2CPP_STRINGIFY_HELPER(patch)
	/**
	 * @brief converts version number to int
	 * @ingroup utils
	 */
	#define _PCRE2CPP_VERSION_TO_INT(major, minor, patch) (major * 100 + minor * 10 + patch)

	/**
	 * @brief pcre2cpp version string
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION_STRING                                                                         \
		_PCRE2CPP_VERSION_TO_STRING(PCRE2CPP_VERSION_MAJOR, PCRE2CPP_VERSION_MINOR, PCRE2CPP_VERSION_PATCH)
	/**
	 * @brief pcre2cpp version int
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION_INT _PCRE2CPP_VERSION_TO_INT(PCRE2CPP_VERSION_MAJOR, PCRE2CPP_VERSION_MINOR, PCRE2CPP_VERSION_PATCH)
	/**
	 * @brief pcre2cpp version string
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_VERSION PCRE2CPP_VERSION_STRING
	#pragma endregion

	#pragma region LAST_UPDATE
	/**
	 * @brief pcre2cpp last update day
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_LAST_UPDATE_DAY 07
	/**
	 * @brief pcre2cpp last update month
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_LAST_UPDATE_MONTH 04
	/**
	 * @brief pcre2cpp last update year
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_LAST_UPDATE_YEAR 2026

	/**
	 * @brief converts last update date to string
	 * @ingroup utils
	 */
	#define _PCRE2CPP_LAST_UPDATE_DATE_HELPER(day, month, year)                                                    \
		_PCRE2CPP_STRINGIFY_HELPER(day) "." _PCRE2CPP_STRINGIFY_HELPER(month) "." _PCRE2CPP_STRINGIFY_HELPER(year)

	/**
	 * @brief pcre2cpp last update date string
	 * @ingroup pcre2cpp
	 */
	#define PCRE2CPP_LAST_UPDATE_DATE                                                                                      \
		_PCRE2CPP_LAST_UPDATE_DATE_HELPER(PCRE2CPP_LAST_UPDATE_DAY, PCRE2CPP_LAST_UPDATE_MONTH, PCRE2CPP_LAST_UPDATE_YEAR)
	#pragma endregion

	#pragma region CXX_VERSIONS
/**
 * @def _PCRE2CPP_HAS_CXX17
 * @brief check if compiler has c++ version greater or equal to c++17
 * @ingroup utils
 */
	#ifndef _HAS_CXX17
	// clang-format off
		#define _PCRE2CPP_HAS_CXX17 __cplusplus >= 201703l
	// clang-format on
	#else
		#define _PCRE2CPP_HAS_CXX17 _HAS_CXX17
	#endif

	/**
	 * @def _PCRE2CPP_HAS_CXX20
	 * @brief check if compiler has c++ version greater or equal to c++20 and if user enabled c++20 features using PCRE2CPP_ENABLE_CXX20
	 * @ingroup utils
	 */
	#ifndef PCRE2CPP_ENABLE_CXX20
		#define _PCRE2CPP_HAS_CXX20 0
	#elif !defined(_HAS_CXX20)
	// clang-format off
		#define _PCRE2CPP_HAS_CXX20 __cplusplus >= 202002l
	// clang-format on
	#else
		#define _PCRE2CPP_HAS_CXX20 _HAS_CXX20
	#endif
	#pragma endregion

/**
 * @def _PCRE2CPP_HAS_EXCEPTIONS
 * @brief check if exceptions are enabled
 * @ingroup utils
 */

/**
 * @def _PCRE2CPP_HAS_ASSERTS
 * @brief check if asserts are enabled
 * @ingroup utils
 */

	#ifdef PCRE2CPP_CHANGE_ASSERTS_TO_EXCEPTIONS
		#define _PCRE2CPP_HAS_EXCEPTIONS _PCRE2CPP_HAS_CXX17
		#define _PCRE2CPP_HAS_ASSERTS	 0
	#else
		#define _PCRE2CPP_HAS_EXCEPTIONS 0
		#define _PCRE2CPP_HAS_ASSERTS	 _PCRE2CPP_HAS_CXX17
	#endif

	#if _PCRE2CPP_HAS_EXCEPTIONS
		#define _PCRE2CPP_NOEXCEPT noexcept
	#else
		#define _PCRE2CPP_NOEXCEPT
	#endif

	#pragma region UTFS_ENABLED
/**
 * @def _PCRE2CPP_HAS_UTF8
 * @brief check if support for UTF-8 is enabled
 * @ingroup utils
 */

/**
 * @def _PCRE2CPP_HAS_UTF16
 * @brief check if support for UTF-16 is enabled
 * @ingroup utils
 */

/**
 * @def _PCRE2CPP_HAS_UTF32
 * @brief check if support for UTF-32 is enabled
 * @ingroup utils
 */

	#ifdef PCRE2CPP_DISABLE_UTF8
		#define _PCRE2CPP_HAS_UTF8 0
	#else
		#define _PCRE2CPP_HAS_UTF8	  1
		#define PCRE2_CODE_UNIT_WIDTH 8
	#endif

	#ifdef PCRE2CPP_DISABLE_UTF16
		#define _PCRE2CPP_HAS_UTF16 0
	#else
		#define _PCRE2CPP_HAS_UTF16 1
		#ifndef PCRE2_CODE_UNIT_WIDTH
			#define PCRE2_CODE_UNIT_WIDTH 16
		#else
			#define PCRE2_CODE_UNIT_WIDTH 0
		#endif
	#endif

	#ifdef PCRE2CPP_DISABLE_UTF32
		#define _PCRE2CPP_HAS_UTF32 0
	#else
		#define _PCRE2CPP_HAS_UTF32 1
		#ifndef PCRE2_CODE_UNIT_WIDTH
			#define PCRE2_CODE_UNIT_WIDTH 32
		#else
			#define PCRE2_CODE_UNIT_WIDTH 0
		#endif
	#endif
	#pragma endregion

	#pragma region VERSION_SPECIFIC_VALUES
/**
 * @def _PCRE2CPP_CONSTEXPR17
 * @brief constexpr for c++17 and higher
 * @ingroup utils
 */
	#if _PCRE2CPP_HAS_CXX17
		#define _PCRE2CPP_CONSTEXPR17 constexpr
	#else
		#define _PCRE2CPP_CONSTEXPR17
	#endif

/**
 * @def _PCRE2CPP_CONSTEXPR20
 * @brief constexpr keyword for c++20 and higher
 * @ingroup utils
 */

/**
 * @def _PCRE2CPP_REQUIRES(condition)
 * @brief requires keyword for c++20 and higher
 * @ingroup utils
 */
	#if _PCRE2CPP_HAS_CXX20
		#define _PCRE2CPP_CONSTEXPR20		  constexpr
		#define _PCRE2CPP_REQUIRES(condition) requires (condition)
	#else
		#define _PCRE2CPP_CONSTEXPR20
		#define _PCRE2CPP_REQUIRES(condition)
	#endif
	#pragma endregion


	/**
	 * @brief compiler message
	 * @ingroup utils
	 */
	#define _PCRE2CPP_MESSAGE(MESSAGE) _MSTD_MESSAGE(MESSAGE)
	/**
	 * @brief compiler warning
	 * @ingroup utils
	 */
	#define _PCRE2CPP_WARNING(MESSAGE) _MSTD_WARNING(MESSAGE)
	/**
	 * @brief compiler error
	 * @ingroup utils
	 */
	#define _PCRE2CPP_ERROR(MESSAGE) _MSTD_ERROR(MESSAGE)
#endif
#pragma endregion // config.hpp

#pragma region libs.hpp
#ifndef _PCRE2CPP_LIBS_HPP_
	#define _PCRE2CPP_LIBS_HPP_


	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else


		#if _PCRE2CPP_HAS_EXCEPTIONS
		#endif

	#endif
#endif
#pragma endregion // libs.hpp

#pragma region types.hpp
#ifndef _PCRE2CPP_TYPES_HPP_
	#define _PCRE2CPP_TYPES_HPP_


	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else


namespace pcre2cpp {
	enum class utf_type : uint8_t;

	namespace utils {
		template<utf_type utf>
		struct pcre2_data;
	}

		#if _PCRE2CPP_HAS_EXCEPTIONS
	template<utf_type utf>
	class basic_pcre2cpp_exception;
	template<utf_type utf>
	class basic_regex_exception;
	template<utf_type utf>
	class basic_match_result_exception;
		#endif

	template<utf_type utf>
	struct basic_match_value;
	struct sub_match_value;
	template<utf_type utf>
	class basic_match_result;
	template<utf_type utf>
	class basic_regex;
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // types.hpp

#pragma region utils_pcre2_data.hpp
#ifndef _PCRE2CPP_PCRE2_DATA_HPP_
	#define _PCRE2CPP_PCRE2_DATA_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else
		#include <pcre2cpp/types.hpp>

namespace pcre2cpp {
	/**
	 * @brief Enum with supported utf types
	 * @ingroup pcre2cpp
	 */
	enum class utf_type : uint8_t {
		#if _PCRE2CPP_HAS_UTF8
		UTF_8 = 8,
		#endif
		#if _PCRE2CPP_HAS_UTF16
		UTF_16 = 16,
		#endif
		#if _PCRE2CPP_HAS_UTF32
		UTF_32 = 32
		#endif
	};
} // namespace pcre2cpp

namespace pcre2cpp::utils {
	/**
	 * @brief Translation container from pcre2 library to pcre2cpp
	 * @ingroup utils
	 * @tparam utf utf coding type (UTF-8 -> utf_type::UTF_8, UTF-16 -> utf_type::UTF_16, UTF-32 -> utf_type::UTF_32)
	 */
	template<utf_type utf>
	struct pcre2_data {};

		#pragma region UTF_8
		#if _PCRE2CPP_HAS_UTF8
	/**
	 * @brief Specialization of Translation container from pcre2 library to pcre2cpp for UTF-8
	 * @ingroup utils
	 */
	template<>
	struct pcre2_data<utf_type::UTF_8> {
			#pragma region CODE
		/// @brief pcre2 code structure type for utf-8
		using code_type								 = pcre2_code_8;
		/// @brief pcre2 compile context structure type for utf-8
		using compile_ctx_type						 = pcre2_compile_context_8;
		/// @brief pcre2 general context structure type for utf-8
		using general_ctx_type						 = pcre2_general_context_8;
			#pragma endregion

			#pragma region MATCH
		/// @brief pcre2 match data structure type for utf-8
		using match_data_type						 = pcre2_match_data_8;
		/// @brief pcre2 match context structure type for utf-8
		using match_ctx_type						 = pcre2_match_context_8;
			#pragma endregion

			#pragma region PCRE2_STRING
		/// @brief pcre2 string pointer type for utf-8
		using sptr_type								 = PCRE2_SPTR8;
		/// @brief pcre2 unsigned char type for utf-8
		using uchar_type							 = PCRE2_UCHAR8;
			#pragma endregion

			#pragma region CPP_STRING
		// #if _PCRE2CPP_HAS_CXX20
		// using string_type						= std::u8string;
		// using string_view_type					= std::u8string_view;
		// #else
		// using string_type						= std::string;
		// using string_view_type					= std::string_view;
		// #endif
		/// @brief cpp string type for utf-8
		using string_type							 = std::string;
		/// @brief cpp string view type for utf-8
		using string_view_type						 = std::string_view;
		/// @brief cpp string char type for utf-8
		using string_char_type						 = string_type::value_type;
			#pragma endregion

			#pragma region UTF_INFO
		/// @brief utf enum value for utf-8
		static _PCRE2CPP_CONSTEXPR17 utf_type uft	 = utf_type::UTF_8;
		/// @brief utf byte size for utf-8
		static _PCRE2CPP_CONSTEXPR17 size_t utf_size = 8;
			#pragma endregion

			#pragma region CODE_FUNCTIONS
		/// @brief pointer to pcre2_compile function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<code_type*(sptr_type, size_t, uint32_t, int*, size_t*, compile_ctx_type*)>
		  compile																= pcre2_compile_8;
		/// @brief pointer to pcre2_code_free function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(code_type*)> code_free = pcre2_code_free_8;
			#pragma endregion

			#pragma region MATCH_DATA_FUNCTIONS
		/// @brief pointer to pcre2_match_data_create_from_pattern function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<match_data_type*(const code_type*, general_ctx_type*)>
		  match_data_from_pattern = pcre2_match_data_create_from_pattern_8;
		/// @brief pointer to pcre2_match_data_free function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(match_data_type*)> match_data_free = pcre2_match_data_free_8;
			#pragma endregion

			#pragma region MATCH_FUNCTIONS
		/// @brief pointer to pcre2_match function for utf-8
		static _PCRE2CPP_CONSTEXPR17
		  mstd::c_func_t<int(const code_type*, sptr_type, size_t, size_t, uint32_t, match_data_type*, match_ctx_type*)>
			match																				  = pcre2_match_8;
			#pragma endregion

			#pragma region OVECTOR_FUNCTIONS
		/// @brief pointer to pcre2_get_ovector_pointer function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<size_t*(match_data_type*)> get_ovector_ptr	  = pcre2_get_ovector_pointer_8;
		/// @brief pointer to pcre2_get_ovector_count function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<uint32_t(match_data_type*)> get_ovector_count = pcre2_get_ovector_count_8;
			#pragma endregion

			#pragma region ERROR_FUNCTIONS
		/// @brief pointer to pcre2_get_error_message function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(int, uchar_type*, size_t)> get_error_message = pcre2_get_error_message_8;
			#pragma endregion

			#pragma region PATTERN_INFO_FUNCTIONS
		/// @brief pointer to pcre2_pattern_info function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, uint32_t, void*)> get_info = pcre2_pattern_info_8;
			#pragma endregion

			#pragma region SUBSTRING_FUNCTIONS
		/// @brief pointer to pcre2_substring_number_from_name function for utf-8
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, sptr_type)> substring_number_from_name =
		  pcre2_substring_number_from_name_8;
			#pragma endregion
	};
		#endif

		#pragma endregion

		#pragma region UTF_16

		#if _PCRE2CPP_HAS_UTF16
	/**
	 * @brief Specialization of Translation container from pcre2 library to pcre2cpp for UTF-16
	 * @ingroup utils
	 */
	template<>
	struct pcre2_data<utf_type::UTF_16> {
			#pragma region CODE
		/// @brief pcre2 code structure type for utf-16
		using code_type								 = pcre2_code_16;
		/// @brief pcre2 compile context structure type for utf-16
		using compile_ctx_type						 = pcre2_compile_context_16;
		/// @brief pcre2 general context structure type for utf-16
		using general_ctx_type						 = pcre2_general_context_16;
			#pragma endregion

			#pragma region MATCH
		/// @brief pcre2 match data structure type for utf-16
		using match_data_type						 = pcre2_match_data_16;
		/// @brief pcre2 match context structure type for utf-16
		using match_ctx_type						 = pcre2_match_context_16;
			#pragma endregion

			#pragma region PCRE2_STRING
		/// @brief pcre2 string pointer type for utf-16
		using sptr_type								 = PCRE2_SPTR16;
		/// @brief pcre2 unsigned char type for utf-16
		using uchar_type							 = PCRE2_UCHAR16;
			#pragma endregion

			#pragma region CPP_STRING
		/// @brief cpp string type for utf-16
		using string_type							 = std::u16string;
		/// @brief cpp string view type for utf-16
		using string_view_type						 = std::u16string_view;
		/// @brief cpp string char type for utf-16
		using string_char_type						 = string_type::value_type;
			#pragma endregion

			#pragma region UTF_INFO
		/// @brief utf enum value for utf-16
		static _PCRE2CPP_CONSTEXPR17 utf_type uft	 = utf_type::UTF_16;
		/// @brief utf byte size for utf-16
		static _PCRE2CPP_CONSTEXPR17 size_t utf_size = 16;
			#pragma endregion

			#pragma region CODE_FUNCTIONS
		/// @brief pointer to pcre2_compile function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<code_type*(sptr_type, size_t, uint32_t, int*, size_t*, compile_ctx_type*)>
		  compile																= pcre2_compile_16;
		/// @brief pointer to pcre2_code_free function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(code_type*)> code_free = pcre2_code_free_16;
			#pragma endregion

			#pragma region MATCH_DATA_FUNCTIONS
		/// @brief pointer to pcre2_match_data_create_from_pattern function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<match_data_type*(const code_type*, general_ctx_type*)>
		  match_data_from_pattern = pcre2_match_data_create_from_pattern_16;
		/// @brief pointer to pcre2_match_data_free function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(match_data_type*)> match_data_free = pcre2_match_data_free_16;
			#pragma endregion

			#pragma region MATCH_FUNCTIONS
		/// @brief pointer to pcre2_match function for utf-16
		static _PCRE2CPP_CONSTEXPR17
		  mstd::c_func_t<int(const code_type*, sptr_type, size_t, size_t, uint32_t, match_data_type*, match_ctx_type*)>
			match																				  = pcre2_match_16;
			#pragma endregion

			#pragma region OVECTOR_FUNCTIONS
		/// @brief pointer to pcre2_get_ovector_pointer function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<size_t*(match_data_type*)> get_ovector_ptr	  = pcre2_get_ovector_pointer_16;
		/// @brief pointer to pcre2_get_ovector_count function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<uint32_t(match_data_type*)> get_ovector_count = pcre2_get_ovector_count_16;
			#pragma endregion

			#pragma region ERROR_FUNCTIONS
		/// @brief pointer to pcre2_get_error_message function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(int, uchar_type*, size_t)> get_error_message = pcre2_get_error_message_16;
			#pragma endregion

			#pragma region PATTERN_INFO_FUNCTIONS
		/// @brief pointer to pcre2_pattern_info function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, uint32_t, void*)> get_info = pcre2_pattern_info_16;
			#pragma endregion

			#pragma region SUBSTRING_FUNCTIONS
		/// @brief pointer to pcre2_substring_number_from_name function for utf-16
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, sptr_type)> substring_number_from_name =
		  pcre2_substring_number_from_name_16;
			#pragma endregion
	};
		#endif

		#pragma endregion

		#pragma region UTF_32

		#if _PCRE2CPP_HAS_UTF32
	/**
	 * @brief Specialization of Translation container from pcre2 library to pcre2cpp for UTF-32
	 * @ingroup utils
	 */
	template<>
	struct pcre2_data<utf_type::UTF_32> {
			#pragma region CODE
		/// @brief pcre2 code structure type for utf-32
		using code_type								 = pcre2_code_32;
		/// @brief pcre2 compile context structure type for utf-32
		using compile_ctx_type						 = pcre2_compile_context_32;
		/// @brief pcre2 general context structure type for utf-32
		using general_ctx_type						 = pcre2_general_context_32;
			#pragma endregion

			#pragma region MATCH
		/// @brief pcre2 match data structure type for utf-32
		using match_data_type						 = pcre2_match_data_32;
		/// @brief pcre2 match context structure type for utf-32
		using match_ctx_type						 = pcre2_match_context_32;
			#pragma endregion

			#pragma region PCRE2_STRING
		/// @brief pcre2 string pointer type for utf-32
		using sptr_type								 = PCRE2_SPTR32;
		/// @brief pcre2 unsigned char type for utf-32
		using uchar_type							 = PCRE2_UCHAR32;
			#pragma endregion

			#pragma region CPP_STRING
		/// @brief cpp string type for utf-32
		using string_type							 = std::u32string;
		/// @brief cpp string view type for utf-32
		using string_view_type						 = std::u32string_view;
		/// @brief cpp string char type for utf-32
		using string_char_type						 = string_type::value_type;
			#pragma endregion

			#pragma region UTF_INFO
		/// @brief utf enum value for utf-32
		static _PCRE2CPP_CONSTEXPR17 utf_type uft	 = utf_type::UTF_32;
		/// @brief utf byte size for utf-32
		static _PCRE2CPP_CONSTEXPR17 size_t utf_size = 32;
			#pragma endregion

			#pragma region CODE_FUNCTIONS
		/// @brief pointer to pcre2_compile function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<code_type*(sptr_type, size_t, uint32_t, int*, size_t*, compile_ctx_type*)>
		  compile																= pcre2_compile_32;
		/// @brief pointer to pcre2_code_free function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(code_type*)> code_free = pcre2_code_free_32;
			#pragma endregion

			#pragma region MATCH_DATA_FUNCTIONS
		/// @brief pointer to pcre2_match_data_create_from_pattern function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<match_data_type*(const code_type*, general_ctx_type*)>
		  match_data_from_pattern = pcre2_match_data_create_from_pattern_32;
		/// @brief pointer to pcre2_match_data_free function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<void(match_data_type*)> match_data_free = pcre2_match_data_free_32;
			#pragma endregion

			#pragma region MATCH_FUNCTIONS
		/// @brief pointer to pcre2_match function for utf-32
		static _PCRE2CPP_CONSTEXPR17
		  mstd::c_func_t<int(const code_type*, sptr_type, size_t, size_t, uint32_t, match_data_type*, match_ctx_type*)>
			match																				  = pcre2_match_32;
			#pragma endregion

			#pragma region OVECTOR_FUNCTIONS
		/// @brief pointer to pcre2_get_ovector_pointer function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<size_t*(match_data_type*)> get_ovector_ptr	  = pcre2_get_ovector_pointer_32;
		/// @brief pointer to pcre2_get_ovector_count function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<uint32_t(match_data_type*)> get_ovector_count = pcre2_get_ovector_count_32;
			#pragma endregion

			#pragma region ERROR_FUNCTIONS
		/// @brief pointer to pcre2_get_error_message function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(int, uchar_type*, size_t)> get_error_message = pcre2_get_error_message_32;
			#pragma endregion

			#pragma region PATTERN_INFO_FUNCTIONS
		/// @brief pointer to pcre2_pattern_info function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, uint32_t, void*)> get_info = pcre2_pattern_info_32;
			#pragma endregion

			#pragma region SUBSTRING_FUNCTIONS
		/// @brief pointer to pcre2_substring_number_from_name function for utf-32
		static _PCRE2CPP_CONSTEXPR17 mstd::c_func_t<int(const code_type*, sptr_type)> substring_number_from_name =
		  pcre2_substring_number_from_name_32;
			#pragma endregion
	};
		#endif

		#pragma endregion

		#if _PCRE2CPP_HAS_UTF8
	using u8pcre2_data = pcre2_data<utf_type::UTF_8>;
		#endif
		#if _PCRE2CPP_HAS_UTF16
	using u16pcre2_data = pcre2_data<utf_type::UTF_16>;
		#endif
		#if _PCRE2CPP_HAS_UTF32
	using u32pcre2_data = pcre2_data<utf_type::UTF_32>;
		#endif
} // namespace pcre2cpp::utils
	#endif
#endif
#pragma endregion // utils_pcre2_data.hpp

#pragma region exceptions_exceptions.hpp
#ifndef _PCRE2CPP_EXCEPTIONS_HPP_
	#define _PCRE2CPP_EXCEPTIONS_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else

		#include <pcre2cpp/types.hpp>
		#include <pcre2cpp/utils/pcre2_data.hpp>
		#if _PCRE2CPP_HAS_ASSERTS
			#include <pcre2cpp/utils/assert.hpp>
		#endif

namespace pcre2cpp {
	/**
	 * @brief Function which generate error message based on pcre2 error code
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 * @param error_code pcre2 error code
	 * @return string value of type compatible with UTF type
	 */
	template<utf_type utf>
	static _PCRE2CPP_CONSTEXPR17 typename utils::pcre2_data<utf>::string_type generate_error_message(
	  const int error_code
	) noexcept {
		using _pcre2_data_t = utils::pcre2_data<utf>;
		using _string_type	= typename _pcre2_data_t::string_type;
		using _uchar_type	= typename _pcre2_data_t::uchar_type;
		using _char_type	= typename _pcre2_data_t::string_char_type;

		_uchar_type error_message[120];
			if (const int size = _pcre2_data_t::get_error_message(error_code, error_message, 120); size != PCRE2_ERROR_BADDATA) {
				return _string_type(reinterpret_cast<_char_type*>(error_message), 120);
			}
		return _string_type();
	}

	/**
	 * @brief Function which generates error message based on pcre2 error code and with additional information about offset
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 * @param error_code pcre2 error code
	 * @param error_offset offset for example in regex pattern
	 * @return string value of type compatible with UTF type
	 */
	template<utf_type utf>
	static _PCRE2CPP_CONSTEXPR17 typename utils::pcre2_data<utf>::string_type generate_error_message(const int error_code,
	  const size_t error_offset) noexcept {
		using _string_type = typename utils::pcre2_data<utf>::string_type;

		#if _PCRE2CPP_HAS_UTF8
			if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_8) {
				return fmt::format("error at {} {}", error_offset, pcre2cpp::generate_error_message<utf>(error_code));
			}
			else
		#endif
		#if _PCRE2CPP_HAS_UTF16
			  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_16) {
				return fmt::format(u"error at {} {}", error_offset, pcre2cpp::generate_error_message<utf>(error_code));
			}
			else
		#endif
		#if _PCRE2CPP_HAS_UTF32
			  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_32) {
				return fmt::format(U"error at {} {}", error_offset, pcre2cpp::generate_error_message<utf>(error_code));
			}
			else
		#endif
			{
				return _string_type();
			}
	}

	/**
	 * @brief converts any message from any utf to utf-8
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 * @param message message to convert
	 * @return std::string value of message
	 */
	template<utf_type utf>
	static _PCRE2CPP_CONSTEXPR20 std::string convert_any_utf_to_utf8(const typename utils::pcre2_data<utf>::string_view_type message) noexcept {
		#if _PCRE2CPP_HAS_UTF8
		if _PCRE2CPP_CONSTEXPR17 (utf == pcre2cpp::utf_type::UTF_8) { return std::string(message); }
		else
			#endif
			#if _PCRE2CPP_HAS_UTF16
			if _PCRE2CPP_CONSTEXPR17 (utf == pcre2cpp::utf_type::UTF_16) {
			std::string msg;
			for (const auto& c : message) { msg += static_cast<std::string::value_type>(c); }
			return msg;
		}
		else
			#endif
			#if _PCRE2CPP_HAS_UTF32
			if _PCRE2CPP_CONSTEXPR17 (utf == pcre2cpp::utf_type::UTF_32) {
			std::string msg;
			for (const auto& c : message) { msg += static_cast<std::string::value_type>(c); }
			return msg;
		}
		else
			#endif
		{
			return std::string();
		}
	}

		#if _PCRE2CPP_HAS_EXCEPTIONS
			#pragma region PCRE2CPP_EXCEPTION

	/**
	 * @brief base pcre2cpp exception class
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	class basic_pcre2cpp_exception : public std::runtime_error {
	private:
		using _pcre2_data_t		= utils::pcre2_data<utf>;
		using _string_type		= typename _pcre2_data_t::string_type;
		using _string_view_type = typename _pcre2_data_t::string_view_type;
		using _uchar_type		= typename _pcre2_data_t::uchar_type;
		using _char_type		= typename _pcre2_data_t::string_char_type;

		/// @brief error message
		_string_type _message;

	public:
		/// @brief constructor with message
		explicit basic_pcre2cpp_exception(const _string_view_type message) noexcept
			: std::runtime_error(convert_any_utf_to_utf8<utf>(message)), _message(message) {}

		/// @brief constructor with error code
		explicit basic_pcre2cpp_exception(const int error_code) noexcept
			: std::runtime_error(convert_any_utf_to_utf8<utf>(generate_error_message<utf>(error_code))),
			  _message(generate_error_message<utf>(error_code)) {}

		/// @brief constructor with error code and error offset
		basic_pcre2cpp_exception(const int error_code, const size_t error_offset) noexcept
			: std::runtime_error(convert_any_utf_to_utf8<utf>(generate_error_message<utf>(error_code, error_offset))),
			  _message(generate_error_message<utf>(error_code, error_offset)) {}

		/// @breif returns error message
		_PCRE2CPP_CONSTEXPR17 const _string_type& get_error() const noexcept { return _message; }
	};

			#if _PCRE2CPP_HAS_UTF8
	using u8pcre2cpp_exception = basic_pcre2cpp_exception<utf_type::UTF_8>;
			#endif
			#if _PCRE2CPP_HAS_UTF16
	using u16pcre2cpp_exception = basic_pcre2cpp_exception<utf_type::UTF_16>;
			#endif
			#if _PCRE2CPP_HAS_UTF32
	using u32pcre2cpp_exception = basic_pcre2cpp_exception<utf_type::UTF_32>;
			#endif

			#if _PCRE2CPP_HAS_UTF8
	using pcre2cpp_exception = u8pcre2cpp_exception;
			#elif _PCRE2CPP_HAS_UTF16
	using pcre2cpp_exception = u16pcre2cpp_exception;
			#elif _PCRE2CPP_HAS_UTF32
	using pcre2cpp_exception = u32pcre2cpp_exception;
			#endif

			#pragma endregion PCRE2CPP_EXCEPTION

			#pragma region REGEX_EXCEPTION

	/**
	 * @brief regex exception class
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	class basic_regex_exception : public basic_pcre2cpp_exception<utf> {
	private:
		using _string_view_type = typename utils::pcre2_data<utf>::string_view_type;

	public:
		/// @brief constructor with message
		explicit basic_regex_exception(const _string_view_type message) noexcept : basic_pcre2cpp_exception<utf>(message) {}

		/// @brief constructor with error code and error offset
		basic_regex_exception(const int error_code, const size_t error_offset) noexcept
			: basic_pcre2cpp_exception<utf>(error_code, error_offset) {}

		using basic_pcre2cpp_exception<utf>::get_error;
	};

			#if _PCRE2CPP_HAS_UTF8
	using u8regex_exception = basic_regex_exception<utf_type::UTF_8>;
			#endif
			#if _PCRE2CPP_HAS_UTF16
	using u16regex_exception = basic_regex_exception<utf_type::UTF_16>;
			#endif
			#if _PCRE2CPP_HAS_UTF32
	using u32regex_exception = basic_regex_exception<utf_type::UTF_32>;
			#endif

			#if _PCRE2CPP_HAS_UTF8
	using regex_exception = u8regex_exception;
			#elif _PCRE2CPP_HAS_UTF16
	using regex_exception = u16regex_exception;
			#elif _PCRE2CPP_HAS_UTF32
	using regex_exception = u32regex_exception;
			#endif

			#pragma endregion REGEX_EXCEPTION

			#pragma region MATCH_RESULT_EXCEPTION

	/**
	 * @brief match result exception class
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	class basic_match_result_exception : public basic_pcre2cpp_exception<utf> {
	private:
		using _string_view_type = typename utils::pcre2_data<utf>::string_view_type;

	public:
		/// @brief constructor with message
		explicit basic_match_result_exception(const _string_view_type message) noexcept
			: basic_pcre2cpp_exception<utf>(message) {}

		/// @brief constructor with error code
		explicit basic_match_result_exception(const int error_code) noexcept : basic_pcre2cpp_exception<utf>(error_code) {}

		using basic_pcre2cpp_exception<utf>::get_error;
	};

			#if _PCRE2CPP_HAS_UTF8
	using u8match_result_exception = basic_match_result_exception<utf_type::UTF_8>;
			#endif
			#if _PCRE2CPP_HAS_UTF16
	using u16match_result_exception = basic_match_result_exception<utf_type::UTF_16>;
			#endif
			#if _PCRE2CPP_HAS_UTF32
	using u32match_result_exception = basic_match_result_exception<utf_type::UTF_32>;
			#endif

			#if _PCRE2CPP_HAS_UTF8
	using match_result_exception = u8match_result_exception;
			#elif _PCRE2CPP_HAS_UTF16
	using match_result_exception = u16match_result_exception;
			#elif _PCRE2CPP_HAS_UTF32
	using match_result_exception = u32match_result_exception;
			#endif

			#pragma endregion MATCH_RESULT_EXCEPTION
		#endif
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // exceptions_exceptions.hpp

#pragma region match_match_options.hpp
#ifndef _PCRE2CPP_REGEX_MATCH_OPTIONS_HPP_
	#define _PCRE2CPP_REGEX_MATCH_OPTIONS_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else

		#include <pcre2cpp/types.hpp>

namespace pcre2cpp {
	/**
	 * @brief Match options
	 * @ingroup pcre2cpp
	 */
	enum class match_options_bits : uint32_t {
		/// @brief No options set (default)
		None					= 0u,
		/// @brief Match only at the first position
		Anchored				= PCRE2_ANCHORED,
		/// @brief On success, make a private subject copy
		CopyMatchedSubject		= PCRE2_COPY_MATCHED_SUBJECT,
		/// @brief Only useful in rare cases; use with care
		DisableRecurseLoopCheck = PCRE2_DISABLE_RECURSELOOP_CHECK,
		/// @brief Pattern can match only at end of subject
		EndAnchored				= PCRE2_ENDANCHORED,
		/// @brief Subject string is not the beginning of a line
		NotBOL					= PCRE2_NOTBOL,
		/// @brief Subject string is not the end of a line
		NotEOL					= PCRE2_NOTEOL,
		/// @brief An empty string is not a valid match
		NotEmpty				= PCRE2_NOTEMPTY,
		/// @brief An empty string at the start of the subject is not a valid match
		NotEmptyAtStart			= PCRE2_NOTEMPTY_ATSTART,
		/// @brief Do not use JIT matching
		NoJIT					= PCRE2_NO_JIT,
		/// @brief Do not check the subject for UTF validity(only relevant if compile_options::UTF was set at compile time)
		NoUTFCheck				= PCRE2_NO_UTF_CHECK,
		/// @brief Return match_error_codes::Partial for a partial match even if there is a full match
		PartialHard				= PCRE2_PARTIAL_HARD,
		/// @brief Return match_error_codes::Partial for a partial match if no full matches are found
		PartialSoft				= PCRE2_PARTIAL_SOFT
	};

	/**
	 * @brief Match options flags group
	 * @ingroup pcre2cpp
	 */
	using match_options = mstd::flags<match_options_bits>;

	/**
	 * @brief operator for combining match options to one flags group
	 * @ingroup pcre2cpp
	 * @param opt0 first match option
	 * @param opt1 second match option
	 * @return Match options flags group created from two match options
	 */
	static _PCRE2CPP_CONSTEXPR17 match_options operator|(const match_options_bits opt0, const match_options_bits opt1) noexcept {
		return mstd::operator|(opt0, opt1);
	}
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // match_match_options.hpp

#pragma region match_match_result.hpp
#ifndef _PCRE2CPP_MATCH_RESULT_HPP_
	#define _PCRE2CPP_MATCH_RESULT_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else

		#include <pcre2cpp/exceptions/exceptions.hpp>
		#include <pcre2cpp/match/match_error_codes.hpp>
		#include <pcre2cpp/types.hpp>
		#include <pcre2cpp/utils/pcre2_data.hpp>

namespace pcre2cpp {
		#pragma region MATCH_VALUE

	/**
	 * @brief Match value container
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	struct basic_match_value {
	private:
		using _string_type = typename utils::pcre2_data<utf>::string_type;

	public:
		/// @brief offset relative to search offset
		size_t relative_offset;
		/// @brief match value
		_string_type value;
	};

		#if _PCRE2CPP_HAS_UTF8
	using u8match_value = basic_match_value<utf_type::UTF_8>;
		#endif
		#if _PCRE2CPP_HAS_UTF16
	using u16match_value = basic_match_value<utf_type::UTF_16>;
		#endif
		#if _PCRE2CPP_HAS_UTF32
	using u32match_value = basic_match_value<utf_type::UTF_32>;
		#endif

		#if _PCRE2CPP_HAS_UTF8
	using match_value = u8match_value;
		#elif _PCRE2CPP_HAS_UTF16
	using match_value = u16match_value;
		#elif _PCRE2CPP_HAS_UTF32
	using match_value = u32match_value;
		#endif
		#pragma endregion

		#pragma region SUB_MATCH_VALUE

	/**
	 * @brief Sub match value container
	 * @ingroup pcre2cpp
	 */
	struct sub_match_value {
		/// @brief offset relative to search offset
		size_t relative_offset;
		/// @brief size of value
		size_t size;
	};

		#pragma endregion

	/**
	 * @brief Basic container to result data of match function
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	class basic_match_result {
	public:
		/// @brief error offset (returned when value doesn't exist or when error has occurred)
		static _PCRE2CPP_CONSTEXPR17 size_t bad_offset = std::numeric_limits<size_t>::max();

	private:
		using _pcre2_data_t		= utils::pcre2_data<utf>;
		using _string_type		= typename _pcre2_data_t::string_type;
		using _string_view_type = typename _pcre2_data_t::string_view_type;
		using _match_value		= basic_match_value<utf>;
		#if _PCRE2CPP_HAS_EXCEPTIONS
		using _match_result_exception = basic_match_result_exception<utf>;
		#endif
		using _named_sub_values_table	  = std::unordered_map<_string_type, size_t>;
		using _named_sub_values_table_ptr = std::shared_ptr<_named_sub_values_table>;

		/// @brief Result data container
		struct _value_result_data {
			size_t search_offset									 = bad_offset;
			_match_value result										 = { bad_offset, _string_type() };
			std::vector<std::optional<sub_match_value> > sub_results = {};
			_named_sub_values_table_ptr named_sub_values			 = {};
			bool found												 = false;
		};

		/// @brief Result data
		std::variant<match_error_codes, _value_result_data> _data = _value_result_data();

		/// @brief returns out of bounds error in correct utf format
		static _PCRE2CPP_CONSTEXPR17 _string_type _get_out_of_bounds_string() noexcept {
		#if _PCRE2CPP_HAS_UTF8
				if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_8) { return "Subexpression index out of bounds or has no value"; }
				else
		#endif
		#if _PCRE2CPP_HAS_UTF16
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_16) {
					return u"Subexpression index out of bounds or has no value";
				}
				else
		#endif
		#if _PCRE2CPP_HAS_UTF32
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_32) {
					return U"Subexpression index out of bounds or has no value";
				}
				else
		#endif
				{
					return _string_type();
				}
		}

		/// @brief returns subexpression not found error in correct utf format
		static _PCRE2CPP_CONSTEXPR17 _string_type _get_subexpression_not_found(const _string_view_type name) noexcept {
		#if _PCRE2CPP_HAS_UTF8
				if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_8) {
					return fmt::format("Subexpression with provided name '{}' not found", name);
				}
				else
		#endif
		#if _PCRE2CPP_HAS_UTF16
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_16) {
					return fmt::format(u"Subexpression with provided name '{}' not found", name);
				}
				else
		#endif
		#if _PCRE2CPP_HAS_UTF32
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_32) {
					return fmt::format(U"Subexpression with provided name '{}' not found", name);
				}
				else
		#endif
				{
					return _string_type();
				}
		}

		/// @brief returns true if sub result group with given name exists in named groups table
		_PCRE2CPP_CONSTEXPR17 bool _has_named_sub_result(const _string_view_type name) const noexcept {
			const auto& named_sub_values = std::get<_value_result_data>(_data).named_sub_values;
		#if _PCRE2CPP_HAS_CXX20
			return named_sub_values->contains(name.data());
		#else
			return named_sub_values->find(name.data()) != named_sub_values->end();
		#endif
		}

		/// @brief returns true if sub result has value and idx wasn't out of bounds
		_PCRE2CPP_CONSTEXPR17 bool _has_sub_value(const size_t idx) const noexcept {
			const auto& subResults = std::get<_value_result_data>(_data).sub_results;
			return idx < subResults.size() && subResults[idx].has_value();
		}

		/// @brief returns group index of group with given name
		_PCRE2CPP_CONSTEXPR17 size_t _get_named_sub_result_idx(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
				if (!_has_named_sub_result(name)) {
		#if _PCRE2CPP_HAS_EXCEPTIONS
					throw _match_result_exception(_get_subexpression_not_found(name));
		#else
					pcre2cpp_assert(false, "{}", _get_subexpression_not_found(name));
					return bad_offset;
		#endif
				}
			return std::get<_value_result_data>(_data).named_sub_values->at(name.data());
		}

		/// @brief returns sub value data of group with provided index
		_PCRE2CPP_CONSTEXPR17 sub_match_value _get_sub_value(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!_has_sub_value(idx)) {
		#if _PCRE2CPP_HAS_EXCEPTIONS
					throw basic_match_result_exception<utf>(_get_out_of_bounds_string());
		#else
					pcre2cpp_assert(false, "{}", _get_out_of_bounds_string());
					return { .relative_offset = bad_offset, .size = 0 };
		#endif
				}

			return std::get<_value_result_data>(_data).sub_results[idx].value();
		}

	public:
		#pragma region CONSTRUCTORS
		/// @brief default constructor
		_PCRE2CPP_CONSTEXPR17 basic_match_result() noexcept = default;

		/// @brief constructor with error code
		_PCRE2CPP_CONSTEXPR17 explicit basic_match_result(const match_error_codes error_code) noexcept : _data(error_code) {}

		/// @brief constructor with no value but also without error
		_PCRE2CPP_CONSTEXPR17 basic_match_result(const size_t search_offset,
		  const _named_sub_values_table_ptr& named_sub_values) noexcept
			: _data(_value_result_data { .search_offset = search_offset, .named_sub_values = named_sub_values }) {}

		/// @brief constructor with good result
		_PCRE2CPP_CONSTEXPR17 basic_match_result(const size_t search_offset, const _match_value& result,
		  const std::vector<std::optional<sub_match_value> >& sub_results,
		  const _named_sub_values_table_ptr& named_sub_values) noexcept
			: _data(_value_result_data { .search_offset = search_offset,
				  .result								= result,
				  .sub_results							= sub_results,
				  .named_sub_values						= named_sub_values,
				  .found								= true }) {}

		/// @brief default copy constructor
		_PCRE2CPP_CONSTEXPR17 basic_match_result(const basic_match_result& other) noexcept			  = default;
		/// @brief default move constructor
		_PCRE2CPP_CONSTEXPR17 basic_match_result(basic_match_result&& other) noexcept				  = default;
		#pragma endregion

		/// @brief default destructor
		_PCRE2CPP_CONSTEXPR20 ~basic_match_result() noexcept										  = default;

		/// @brief default copy assign operator
		_PCRE2CPP_CONSTEXPR17 basic_match_result& operator=(const basic_match_result& other) noexcept = default;
		/// @brief default move assign operator
		_PCRE2CPP_CONSTEXPR17 basic_match_result& operator=(basic_match_result&& other) noexcept	  = default;

		#pragma region ERRORS

		/// @brief returns true if result holds error
		_PCRE2CPP_CONSTEXPR17 bool has_error() const noexcept { return std::holds_alternative<match_error_codes>(_data); }

		/// @brief return error code
		_PCRE2CPP_CONSTEXPR17 match_error_codes get_error_code() const noexcept {
				if (!has_error()) { return match_error_codes::None; }
			return std::get<match_error_codes>(_data);
		}

		/// @brief returns error message
		_PCRE2CPP_CONSTEXPR17 _string_type get_error_message() const noexcept {
				if (!has_error()) { return _string_type(); }
			return pcre2cpp::generate_error_message<utf>(static_cast<int>(std::get<match_error_codes>(_data)));
		}

		#if _PCRE2CPP_HAS_EXCEPTIONS
		/// @brief throws error if result holds error with error message based on error code
		_PCRE2CPP_CONSTEXPR17 void throw_error() const {
				if (!has_error()) { return; }
			throw _match_result_exception(static_cast<int>(std::get<match_error_codes>(_data)));
		}
		#endif

		#pragma endregion ERRORS

		#pragma region RESULTS

		/// @brief returns true when result holds some result not error
		_PCRE2CPP_CONSTEXPR17 bool has_result() const noexcept { return std::holds_alternative<_value_result_data>(_data); }

		/// @brief returns true when result has value
		_PCRE2CPP_CONSTEXPR17 bool has_value() const noexcept {
				if (!has_result()) { return false; }
			return std::get<_value_result_data>(_data).found;
		}

		/// @brief returns true when result has sub value on given index
		_PCRE2CPP_CONSTEXPR17 bool has_sub_value(const size_t idx) const noexcept {
				if (!has_value()) { return false; }
			return _has_sub_value(idx);
		}

		/// @brief returns true when result has sub value with given name
		_PCRE2CPP_CONSTEXPR17 bool has_sub_value(const _string_view_type name) const noexcept {
			return _has_named_sub_result(name) && has_sub_value(_get_named_sub_result_idx(name));
		}

		/// @brief returns search offset
		_PCRE2CPP_CONSTEXPR17 size_t get_search_offset() const noexcept {
				if (!has_result()) { return bad_offset; }
			return std::get<_value_result_data>(_data).search_offset;
		}

		#pragma region RESULT

		/// @brief returns match result container
		_PCRE2CPP_CONSTEXPR17 _match_value get_result() const noexcept {
				if (!has_value()) { return { bad_offset, _string_type() }; }
			return std::get<_value_result_data>(_data).result;
		}

		/// @brief returns offset of value from the beginning of searched string
		_PCRE2CPP_CONSTEXPR17 size_t get_result_global_offset() const noexcept {
				if (!has_value()) { return bad_offset; }
			const auto& value = std::get<_value_result_data>(_data);
			return value.search_offset + value.result.relative_offset;
		}

		/// @brief return offset relative to search offset
		_PCRE2CPP_CONSTEXPR17 size_t get_result_relative_offset() const noexcept {
				if (!has_value()) { return bad_offset; }
			return std::get<_value_result_data>(_data).result.relative_offset;
		}

		/// @brief returns size of match value
		_PCRE2CPP_CONSTEXPR17 size_t get_result_size() const noexcept {
				if (!has_value()) { return 0; }
			return std::get<_value_result_data>(_data).result.value.size();
		}

		/// @brief returns match string value
		_PCRE2CPP_CONSTEXPR17 _string_type get_result_value() const noexcept {
				if (!has_value()) { return _string_type(); }
			return std::get<_value_result_data>(_data).result.value;
		}

		#pragma endregion RESULT

		#pragma region ALL_SUB_RESULTS

		/// @brief returns all sub results
		_PCRE2CPP_CONSTEXPR20 std::vector<std::optional<sub_match_value> > get_sub_results() const noexcept {
				if (!has_value()) { return {}; }
			return std::get<_value_result_data>(_data).sub_results;
		}

		/// @brief returns sub results count
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_results_count() const noexcept { return get_sub_results().size(); }

		/// @brief returns sub results offsets from the beginning of search string
		_PCRE2CPP_CONSTEXPR20 std::vector<size_t> get_sub_results_global_offsets() const noexcept {
				if (!has_value()) { return {}; }

			const auto& value = std::get<_value_result_data>(_data);

			std::vector<size_t> offsets;
			offsets.reserve(value.sub_results.size());
				for (const auto& subResult : value.sub_results) {
						if (subResult.has_value()) {
							offsets.push_back(value.search_offset + value.result.relative_offset + subResult->relative_offset);
						}
						else { offsets.push_back(bad_offset); }
				}
			return offsets;
		}

		/// @brief returns sub results offsets relative to search offset
		_PCRE2CPP_CONSTEXPR20 std::vector<size_t> get_sub_results_relative_offsets() const noexcept {
				if (!has_value()) { return {}; }

			const auto& value = std::get<_value_result_data>(_data);

			std::vector<size_t> offsets;
			offsets.reserve(value.sub_results.size());
				for (const auto& subResult : value.sub_results) {
						if (subResult.has_value()) {
							offsets.push_back(value.result.relative_offset + subResult->relative_offset);
						}
						else { offsets.push_back(bad_offset); }
				}
			return offsets;
		}

		/// @brief returns sub results offsets relative to result offset
		_PCRE2CPP_CONSTEXPR20 std::vector<size_t> get_sub_results_in_result_offsets() const noexcept {
				if (!has_value()) { return {}; }

			const auto& sub_results = std::get<_value_result_data>(_data).sub_results;

			std::vector<size_t> offsets;
			offsets.reserve(sub_results.size());
				for (const auto& subResult : sub_results) {
						if (subResult.has_value()) { offsets.push_back(subResult->relative_offset); }
						else { offsets.push_back(bad_offset); }
				}
			return offsets;
		}

		/// @brief returns sub results value sizes
		_PCRE2CPP_CONSTEXPR20 std::vector<size_t> get_sub_results_sizes() const noexcept {
				if (!has_value()) { return {}; }

			const auto& sub_results = std::get<_value_result_data>(_data).sub_results;

			std::vector<size_t> values;
			values.reserve(sub_results.size());
				for (const auto& subResult : sub_results) {
						if (subResult.has_value()) { values.emplace_back(subResult->size); }
						else { values.push_back(0); }
				}
			return values;
		}

		/// @brief returns sub results string values
		_PCRE2CPP_CONSTEXPR17 std::vector<_string_type> get_sub_results_values() const noexcept {
				if (!has_value()) { return {}; }

			const auto& data		= std::get<_value_result_data>(_data);
			const auto& value		= data.result.value;
			const auto& sub_results = data.sub_results;

			std::vector<_string_type> values;
			values.reserve(sub_results.size());
				for (const auto& subResult : sub_results) {
						if (subResult.has_value()) {
							values.emplace_back(value.data() + subResult->relative_offset, subResult->size);
						}
						else { values.push_back(_string_type()); }
				}
			return values;
		}

		#pragma endregion ALL_SUB_RESULTS

		#pragma region SUB_RESULTS_BY_IDX

		/// @brief returns sub result container
		_PCRE2CPP_CONSTEXPR17 sub_match_value get_sub_result(const size_t idx) const _PCRE2CPP_NOEXCEPT {
			return _get_sub_value(idx);
		}

		/// @brief returns sub result offset from the beginning of searched string
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_global_offset(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!has_sub_value(idx)) { return bad_offset; }

			const auto [relative_offset, size] = _get_sub_value(idx);
			const auto& value				   = std::get<_value_result_data>(_data);
			return value.search_offset + value.result.relative_offset + relative_offset;
		}

		/// @brief returns sub result offset relative to search offset
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_relative_offset(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!has_sub_value(idx)) { return bad_offset; }

			const auto [relative_offset, size] = _get_sub_value(idx);
			const auto& value				   = std::get<_value_result_data>(_data);
			return value.result.relative_offset + relative_offset;
		}

		/// @brief returns sub result offset relative to result offset
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_in_result_offset(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!has_sub_value(idx)) { return bad_offset; }
			return _get_sub_value(idx).relative_offset;
		}

		/// @brief returns sub result value size
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_size(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!has_sub_value(idx)) { return 0; }
			return _get_sub_value(idx).size;
		}

		/// @brief returns sub result string value
		_PCRE2CPP_CONSTEXPR17 _string_type get_sub_result_value(const size_t idx) const _PCRE2CPP_NOEXCEPT {
				if (!has_sub_value(idx)) { return _string_type(); }

			const auto [relative_offset, size] = _get_sub_value(idx);
			const auto& value				   = std::get<_value_result_data>(_data).result.value;
			return _string_type(value.data() + relative_offset, size);
		}

		#pragma endregion

		#pragma region SUB_RESULTS_BY_NAME

		/// @brief returns sub result container
		_PCRE2CPP_CONSTEXPR17 sub_match_value get_sub_result(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result(_get_named_sub_result_idx(name));
		}

		/// @brief returns sub result offset from the beginning of searched string
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_global_offset(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result_global_offset(_get_named_sub_result_idx(name));
		}

		/// @brief returns sub result offset relative to search offset
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_relative_offset(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result_relative_offset(_get_named_sub_result_idx(name));
		}

		/// @brief returns sub result offset relative to result offset
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_in_result_offset(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result_in_result_offset(_get_named_sub_result_idx(name));
		}

		/// @brief returns sub result value size
		_PCRE2CPP_CONSTEXPR17 size_t get_sub_result_size(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result_size(_get_named_sub_result_idx(name));
		}

		/// @brief returns sub result string value
		_PCRE2CPP_CONSTEXPR17 _string_type get_sub_result_value(const _string_view_type name) const _PCRE2CPP_NOEXCEPT {
			return get_sub_result_value(_get_named_sub_result_idx(name));
		}

		#pragma endregion

		#pragma endregion RESULTS
	};

		#if _PCRE2CPP_HAS_UTF8
	using u8match_result = basic_match_result<utf_type::UTF_8>;
		#endif
		#if _PCRE2CPP_HAS_UTF16
	using u16match_result = basic_match_result<utf_type::UTF_16>;
		#endif
		#if _PCRE2CPP_HAS_UTF32
	using u32match_result = basic_match_result<utf_type::UTF_32>;
		#endif

		#if _PCRE2CPP_HAS_UTF8
	using match_result = u8match_result;
		#elif _PCRE2CPP_HAS_UTF16
	using match_result = u16match_result;
		#elif _PCRE2CPP_HAS_UTF32
	using match_result = u32match_result;
		#endif
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // match_match_result.hpp

#pragma region regex_compile_options.hpp
#ifndef _PCRE2CPP_COMPILE_OPTIONS_HPP_
	#define _PCRE2CPP_COMPILE_OPTIONS_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else

		#include <pcre2cpp/types.hpp>

namespace pcre2cpp {
	/**
	 * @brief Compile options
	 * @ingroup pcre2cpp
	 */
	enum class compile_options_bits : uint32_t {
		/// @brief No options set (default)
		None			  = 0u,
		/// @brief Force pattern anchoring
		Anchored		  = PCRE2_ANCHORED,
		/// @brief Allow empty classes
		AllowEmptyClass	  = PCRE2_ALLOW_EMPTY_CLASS,
		/// @brief Alternative handling of \u, \U, and \x
		AltBSUX			  = PCRE2_ALT_BSUX,
		/// @brief Alternative handling of ^ in multiline mode
		AltCircumflex	  = PCRE2_ALT_CIRCUMFLEX,
		/// @brief Process backslashes in verb names
		AltVerbNames	  = PCRE2_ALT_VERBNAMES,
		/// @brief Compile automatic callouts
		AutoCallout		  = PCRE2_AUTO_CALLOUT,
		/// @brief Do caseless matching
		Caseless		  = PCRE2_CASELESS,
		/// @brief $ not to match newline at end
		DollarEndonly	  = PCRE2_DOLLAR_ENDONLY,
		/// @brief . matches anything including NL
		DotAll			  = PCRE2_DOTALL,
		/// @brief Allow duplicate names for subpatterns
		DupNames		  = PCRE2_DUPNAMES,
		/// @brief Pattern can match only at end of subject
		EndAnchored		  = PCRE2_ENDANCHORED,
		/// @brief Ignore white space and # comments
		Extended		  = PCRE2_EXTENDED,
		/// @brief Force matching to be before newline
		FirstLine		  = PCRE2_FIRSTLINE,
		/// @brief Pattern characters are all literal
		Literal			  = PCRE2_LITERAL,
		/// @brief Enable support for matching invalid UTF
		MatchInvalidUTF	  = PCRE2_MATCH_INVALID_UTF,
		/// @brief Match unset backreferences
		MatchUnsetBackRef = PCRE2_MATCH_UNSET_BACKREF,
		/// @brief ^ and $ match newlines within data
		Multiline		  = PCRE2_MULTILINE,
		/// @brief Lock out the use of \C in patterns
		NeverBackslashC	  = PCRE2_NEVER_BACKSLASH_C,
		/// @brief Lock out PCRE2_UCP, e.g.via(*UCP)
		NeverUCP		  = PCRE2_NEVER_UCP,
		/// @brief Lock out PCRE2_UTF, e.g.via(*UTF)
		NeverUTF		  = PCRE2_NEVER_UTF,
		/// @brief Disable numbered capturing paren - theses(named ones available)
		NoAutoCapture	  = PCRE2_NO_AUTO_CAPTURE,
		/// @brief Disable auto - possessification
		NoAutoPossess	  = PCRE2_NO_AUTO_POSSESS,
		/// @brief Disable automatic anchoring for .*
		NoDotStarAnchor	  = PCRE2_NO_DOTSTAR_ANCHOR,
		/// @brief Disable match - time start optimizations
		NoStartOptimize	  = PCRE2_NO_START_OPTIMIZE,
		/// @brief Do not check the pattern for UTF validity (only relevant if PCRE2_UTF is set)
		NoUTFCheck		  = PCRE2_NO_UTF_CHECK,
		/// @brief Use Unicode properties for \d, \w, etc.
		UCP				  = PCRE2_UCP,
		/// @brief Invert greediness of quantifiers
		UnGreedy		  = PCRE2_UNGREEDY,
		/// @brief Enable offset limit for unanchored matching
		UseOffsetLimit	  = PCRE2_USE_OFFSET_LIMIT,
		/// @brief Treat pattern and subjects as UTF strings
		UTF				  = PCRE2_UTF
	};

	/**
	 * @brief Compile options flags group
	 * @ingroup pcre2cpp
	 */
	using compile_options = mstd::flags<compile_options_bits>;

	/**
	 * @brief operator for combining compile options to one flags group
	 * @param opt0 first compile option
	 * @param opt1 second compile option
	 * @return Compile options flags group created from two compile options
	 */
	static _PCRE2CPP_CONSTEXPR17 compile_options operator|(const compile_options_bits opt0,
	  const compile_options_bits opt1) noexcept {
		return mstd::operator|(opt0, opt1);
	}
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // regex_compile_options.hpp

#pragma region regex_regex.hpp
#ifndef _PCRE2CPP_REGEX_HPP_
	#define _PCRE2CPP_REGEX_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else

		#include <pcre2cpp/exceptions/exceptions.hpp>
		#include <pcre2cpp/match/match_error_codes.hpp>
		#include <pcre2cpp/match/match_options.hpp>
		#include <pcre2cpp/match/match_result.hpp>
		#include <pcre2cpp/regex/compile_options.hpp>
		#include <pcre2cpp/types.hpp>
		#include <pcre2cpp/utils/pcre2_data.hpp>

namespace pcre2cpp {
	/**
	 * @brief Basic PCRE2 Regex container
	 * @ingroup pcre2cpp
	 * @tparam utf UTF type
	 */
	template<utf_type utf>
	class basic_regex {
	private:
		using _pcre2_data_t				  = utils::pcre2_data<utf>;

		using _code_type				  = typename _pcre2_data_t::code_type;
		using _code_ptr					  = std::shared_ptr<_code_type>;
		using _match_data_type			  = typename _pcre2_data_t::match_data_type;
		using _match_data_ptr			  = std::shared_ptr<_match_data_type>;
		using _string_type				  = typename _pcre2_data_t::string_type;
		using _string_view_type			  = typename _pcre2_data_t::string_view_type;
		using _string_char_type			  = typename _pcre2_data_t::string_char_type;
		using _match_value_type			  = basic_match_value<utf>;
		using _match_result_type		  = basic_match_result<utf>;
		using _sptr_type				  = typename _pcre2_data_t::sptr_type;
		using _named_sub_values_table	  = std::unordered_map<_string_type, size_t>;
		using _named_sub_values_table_ptr = std::shared_ptr<_named_sub_values_table>;
		using _uchar_type				  = typename _pcre2_data_t::uchar_type;
		#if _PCRE2CPP_HAS_EXCEPTIONS
		using _regex_exception = basic_regex_exception<utf>;
		#endif

		/// @brief pointer to compiled pcre2 code
		_code_ptr _code								  = nullptr;
		/// @brief pointer to match data of pcre2 code
		_match_data_ptr _match_data					  = nullptr;
		/// @brief pointer to conversion table of named groups to their index
		_named_sub_values_table_ptr _named_sub_values = nullptr;

		/// @brief error code
		int _error_code								  = 0;
		/// @brief error offset
		size_t _error_offset						  = 0;

		static _PCRE2CPP_CONSTEXPR17 _string_type _get_regex_not_initialized_error() noexcept {
		#if _PCRE2CPP_HAS_UTF8
				if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_8) { return "Regex was not initialized!!"; }
				else
		#endif
		#if _PCRE2CPP_HAS_UTF16
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_16) {
					return u"Regex was not initialized!!";
				}
				else
		#endif
		#if _PCRE2CPP_HAS_UTF32
				  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_32) {
					return U"Regex was not initialized!!";
				}
				else
		#endif
				{
					return _string_type();
				}
		}

	public:
		/// @brief basic regex container with pattern and compile options
		_PCRE2CPP_CONSTEXPR20 explicit basic_regex(const _string_view_type pattern,
		  const compile_options opts = compile_options_bits::None) _PCRE2CPP_NOEXCEPT {
			// Compile Code
			_code_type* code = _pcre2_data_t::compile(reinterpret_cast<_sptr_type>(pattern.data()), pattern.size(), opts,
			  &_error_code, &_error_offset, nullptr);

				if (code == nullptr) {
		#if !_PCRE2CPP_HAS_EXCEPTIONS
					std::string message = fmt::format("Failed to initialize code: {}",
					  convert_any_utf_to_utf8<utf>(generate_error_message<utf>(_error_code, _error_offset)));
					pcre2cpp_assert(false, "{}", message);
					return;
		#else
					throw _regex_exception(_error_code, _error_offset);
		#endif
				}

			_code					= std::shared_ptr<_code_type>(code, _pcre2_data_t::code_free);

			// Get Named Sub Values
			_named_sub_values		= std::make_shared<_named_sub_values_table>();

			size_t name_count		= 0;
			_uchar_type* name_table = nullptr;
			size_t name_entry_size	= 0;

			_pcre2_data_t::get_info(_code.get(), PCRE2_INFO_NAMECOUNT, &name_count);
			_pcre2_data_t::get_info(_code.get(), PCRE2_INFO_NAMETABLE, &name_table);
			_pcre2_data_t::get_info(_code.get(), PCRE2_INFO_NAMEENTRYSIZE, &name_entry_size);

				for (size_t i = 0; i != name_count; ++i) {
					_uchar_type* entry	   = name_table + i * name_entry_size + 2;
					const int index		   = _pcre2_data_t::substring_number_from_name(_code.get(), entry);

					_uchar_type* entry_end = entry + 1;
						while (*entry_end != 0 && entry_end - entry < name_entry_size - 3) { entry_end += 1; }
					_named_sub_values->emplace(_string_type(entry, entry_end), static_cast<size_t>(index) - 1);
				}

			// Create Match Data
			_match_data_type* match_data = _pcre2_data_t::match_data_from_pattern(_code.get(), nullptr);
			_match_data					 = std::shared_ptr<_match_data_type>(match_data, _pcre2_data_t::match_data_free);
		}

		/// @brief default copy constructor
		_PCRE2CPP_CONSTEXPR17 basic_regex(const basic_regex& other) noexcept			= default;
		/// @brief default move constructor
		_PCRE2CPP_CONSTEXPR17 basic_regex(basic_regex&& other) noexcept					= default;

		/// @brief default destructor
		_PCRE2CPP_CONSTEXPR20 ~basic_regex() noexcept									= default;

		/// @brief default copy assign operator
		_PCRE2CPP_CONSTEXPR17 basic_regex& operator=(const basic_regex& other) noexcept = default;
		/// @brief default move assign operator
		_PCRE2CPP_CONSTEXPR17 basic_regex& operator=(basic_regex&& other) noexcept		= default;

		#pragma region CHECK_INITIALIZATION

		/// @brief returns true if regex was initialized
		_PCRE2CPP_CONSTEXPR17 bool is_initialized() const noexcept { return _code != nullptr; }

		#pragma endregion CHECK_INITIALIZATION

		#pragma region ERROR

		/// @brief returns error message if there is any compilation error
		_PCRE2CPP_CONSTEXPR17 _string_type get_error_message() const noexcept {
				if (is_initialized()) {
		#if _PCRE2CPP_HAS_UTF8
						if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_8) { return ""; }
						else
		#endif
		#if _PCRE2CPP_HAS_UTF16
						  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_16) {
							return L"";
						}
						else
		#endif
		#if _PCRE2CPP_HAS_UTF32
						  if _PCRE2CPP_CONSTEXPR17 (utf == utf_type::UTF_32) {
							return U"";
						}
						else
		#endif
						{
							return _string_type();
						}
				}
			return pcre2cpp::generate_error_message<utf>(_error_code, _error_offset);
		}

		#pragma endregion ERROR

		/// @brief returns true if match was found
		_PCRE2CPP_CONSTEXPR17 bool match(const _string_view_type text, const size_t offset = 0,
		  const match_options opts = match_options_bits::None) const _PCRE2CPP_NOEXCEPT {
				if (!is_initialized()) {
		#if !_PCRE2CPP_HAS_EXCEPTIONS
					pcre2cpp_assert(false, "Regex was not initialized!!");
					return false;
		#else
					throw _regex_exception(_get_regex_not_initialized_error());
		#endif
				}

			const int match_code = _pcre2_data_t::match(_code.get(), reinterpret_cast<_sptr_type>(text.data()), text.size(),
			  offset, opts, _match_data.get(), nullptr);

			return match_code != static_cast<int>(match_error_codes::NoMatch) && match_code > 0;
		}

		/// @brief returns true if match was found and result is stored in result variable
		_PCRE2CPP_CONSTEXPR20 bool match(const _string_view_type text, _match_result_type& result, const size_t offset = 0,
		  const match_options opts = match_options_bits::None) const noexcept {
				if (!is_initialized()) {
		#if !_PCRE2CPP_HAS_EXCEPTIONS
					pcre2cpp_assert(false, "Regex was not initialized!!");
					return false;
		#else
					throw _regex_exception(_get_regex_not_initialized_error());
		#endif
				}

			const int match_code = _pcre2_data_t::match(_code.get(), reinterpret_cast<_sptr_type>(text.data()), text.size(),
			  offset, opts, _match_data.get(), nullptr);

				if (match_code == static_cast<int>(match_error_codes::NoMatch) || match_code <= 0) {
					result = _match_result_type(static_cast<match_error_codes>(match_code));
					return false;
				}

			const size_t* offsetVector		= _pcre2_data_t::get_ovector_ptr(_match_data.get());
			const size_t matchStart			= offsetVector[0];
			const size_t matchEnd			= offsetVector[1];
			_match_value_type value			= { .relative_offset = matchStart - offset,
				.value									 = _string_type(text.substr(matchStart, matchEnd - matchStart)) };

			const size_t offsetVectorsCount = _pcre2_data_t::get_ovector_count(_match_data.get());
			std::vector<std::optional<sub_match_value> > sub_values;
			sub_values.reserve(offsetVectorsCount);
				for (size_t i = 1; i != offsetVectorsCount; ++i) {
					const size_t subMatchStart = offsetVector[i * 2];
					const size_t subMatchEnd   = offsetVector[i * 2 + 1];

						if (subMatchStart == PCRE2_UNSET || subMatchEnd == PCRE2_UNSET) { sub_values.emplace_back(); }
						else {
							sub_values.push_back(sub_match_value { .relative_offset = subMatchStart - matchStart,
								.size												= subMatchEnd - subMatchStart });
						}
				}

			result = _match_result_type(offset, value, sub_values, _named_sub_values);
			return true;
		}

		/// @brief returns true if match was found, and it has relative offset == 0
		_PCRE2CPP_CONSTEXPR17 bool match_at(const _string_view_type text, const size_t offset = 0) const noexcept {
			_match_result_type result;
			return match_at(text, result, offset);
		}

		/// @brief returns true if match was found, and it has relative offset == 0 and result is stored in result variable
		_PCRE2CPP_CONSTEXPR17 bool match_at(const _string_view_type text, _match_result_type& result,
		  const size_t offset = 0) const noexcept {
				if (!match(text, result, offset)) { return false; }

				if (result.get_result_relative_offset() != 0) {
					result = _match_result_type(offset, _named_sub_values);
					return false;
				}

			return true;
		}

		/// @brief returns true if any match was found and all results store in results array
		_PCRE2CPP_CONSTEXPR17 bool match_all(const _string_view_type text, std::vector<_match_result_type>& results,
		  size_t offset = 0) const noexcept {
			size_t start_offset = offset;
			_match_result_type result;
				while (match(text, result, offset)) {
					results.emplace_back(start_offset,
					  _match_value_type { .relative_offset = offset - start_offset + result.get_result_relative_offset(),
						  .value						   = result.get_result_value() },
					  result.get_sub_results(), _named_sub_values);
					offset += result.get_result_relative_offset() + result.get_result_size();
				}

			return results.size() != 0;
		}
	};

		#if _PCRE2CPP_HAS_UTF8
	using u8regex = basic_regex<utf_type::UTF_8>;
		#endif
		#if _PCRE2CPP_HAS_UTF16
	using u16regex = basic_regex<utf_type::UTF_16>;
		#endif
		#if _PCRE2CPP_HAS_UTF32
	using u32regex = basic_regex<utf_type::UTF_32>;
		#endif

		#if _PCRE2CPP_HAS_UTF8
	using regex = u8regex;
		#elif _PCRE2CPP_HAS_UTF16
	using regex = u16regex;
		#elif _PCRE2CPP_HAS_UTF32
	using regex = u32regex;
		#endif
} // namespace pcre2cpp
	#endif
#endif
#pragma endregion // regex_regex.hpp

#pragma region utils_assert.hpp
#ifndef _PCRE2CPP_ASSERT_HPP_
	#define _PCRE2CPP_ASSERT_HPP_

	#include <pcre2cpp/config.hpp>

	#if !_PCRE2CPP_HAS_ASSERTS
_PCRE2CPP_ERROR("This is only available for c++17 and greater and when asserts are enabled!");
	#else


	/**
	 * @def pcre2cpp_assert(expression, ...)
	 * @brief pcre2cpp assert
	 * @ingroup utils
	 */

		#if _DEBUG
			#define pcre2cpp_assert(expression, ...)                                                                \
				MSTD_STOP_ASSERT_BASE(expression, [](const std::string_view) -> void {} __VA_OPT__(, ) __VA_ARGS__)
		#elif !defined(PCRE2CPP_DISABLE_ASSERT_ON_RELEASE)
			#define pcre2cpp_assert(expression, ...)                                                               \
				MSTD_LOG_ASSERT_BASE(expression, [](const std::string_view) -> void {} __VA_OPT__(, ) __VA_ARGS__)
		#else
			#define pcre2cpp_assert(expression, ...)                                                                 \
				MSTD_EMPTY_ASSERT_BASE(expression, [](const std::string_view) -> void {} __VA_OPT__(, ) __VA_ARGS__)
		#endif

	#endif
#endif
#pragma endregion // utils_assert.hpp

#pragma region pcre2cpp.hpp
#ifndef _PCRE2CPP_PCRE2CPP_HPP_
	#define _PCRE2CPP_PCRE2CPP_HPP_


	#if !_PCRE2CPP_HAS_CXX17
_PCRE2CPP_ERROR("This is only available for c++17 and greater!");
	#else




		#if _PCRE2CPP_HAS_ASSERTS
		#endif

	#endif
#endif
#pragma endregion // pcre2cpp.hpp

